#ifndef OS_MODULES_H
#define OS_MODULES_H

#include "stdio.h"
#include "interrupt.h"

extern InterruptManager interruptManager;
extern STDIO stdio;

#endif